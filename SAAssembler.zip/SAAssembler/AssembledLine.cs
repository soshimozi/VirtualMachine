﻿namespace MacroAssembler
{
    struct AssembledLine
    {
        public byte Location, Opcode, Address;
    }
}