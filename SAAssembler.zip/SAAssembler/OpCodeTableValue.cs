namespace MacroAssembler
{
    struct OpCodeTableValue
    {
        public string Spelling;
        public byte Byt;
    }
}